//RIYA SHAH, 201817129
//CS2004, ASSIGNMENT 6
//Q1


#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>


int sum = 0; // variable to store the sum
int read_val = 0; // variable to store the value read from user
int rw_bit = 1; // read or write bit, 0 - read, 1- write


void *read_thd() {
do { 
while(!rw_bit) // wait until rw_bit becomes one
sleep(1); 

// Now sleep 1 more sec to avoid printing disturbances on console
sleep(1); 

   
   int val;
printf("READ :: Input a number : ");
scanf("%d", &val);

//printf("READ :: Assigning the Read value!!\n");
read_val = val; // store the val in shared memory
rw_bit = 0; // set rw_bit to 0 so that sum function can resume

   // exit the thread if the value read is negative
if(val < 0) {
//printf("READ :: Exiting due to negative input!!\n");
pthread_exit(NULL);
}
} while(1);
}


void *sum_thd() {
do { // run indefinitely
while(rw_bit) // wait till the rw_bit is set
sleep(1); // for Unix & Ubuntu add this -> sleep(1);
int val = read_val; // read the value from shared memory


if(val < 0) { // if the value is -ve, exit

pthread_exit(NULL);
}
sum += val; // add the value to the sum
  
rw_bit = 1; // set the rw_bit to 1, so that read thread can execute
} while(1);
}

int main() {
pthread_t read_t_id;
pthread_t sum_t_id;

// create the read thread
//printf("MAIN :: Creating Read thread!!\n");
pthread_create(&read_t_id, NULL, read_thd, NULL);

// create the sum thread
//printf("MAIN :: Creating Sum thread!!\n");
pthread_create(&sum_t_id, NULL, sum_thd, NULL);

// block the main thread until the sum thread exits
pthread_join(sum_t_id, NULL);
//printf("MAIN :: Read and Sum threads exited!!\n");
printf("MAIN :: The sum is %d\n", sum);

return 0;
}